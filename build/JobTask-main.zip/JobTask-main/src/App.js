import React from 'react'
import Customer from './component/Customer'

export default function App() {
  return <>
<Customer/>
</>

}
