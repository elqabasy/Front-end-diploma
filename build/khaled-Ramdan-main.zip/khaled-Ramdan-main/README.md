
<h1 align="center">Hi <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="28">, I'm Khaled Ramadan</h1>

<!-- Typing SVG by DenverCoder1 - https://github.com/DenverCoder1/readme-typing-svg -->
<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com/?lines=Back-end%20web%20developer;Always%20learning%20new%20things&font=Fira%20Code&center=true&width=440&height=45&color=f75c7e&vCenter=true&size=22"></a>
</p> 
<!-- <p align="left"> <img src="https://komarev.com/ghpvc/?username=khaled-Ramdan&label=Profile%20views&color=0e75b6&style=flat" alt="khaled" /> </p> -->

- 🏢 I'm a software Engineer.
- 👨‍💻 I'm constantly learning and exploring new technologies to improve my skills.
- 📫 How to reach me **<khaled2346@gmail.com>**


<h3 align="left"> 🤝🏻 &nbsp;Connect with Me </h3>
<p align="left">
<!-- linkedin -->
<a href="https://www.linkedin.com/in/khaled-ramadan" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="mohamed-aabdelmagid" height="30" width="40" /></a>
<!-- stackoverflow -->
<a href="https://stackoverflow.com/users/17018121/khaled-ramadan" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/stack-overflow.svg" alt="7477881" height="30" width="40" /></a>
<!-- hackerrank -->
<a href="https://www.hackerrank.com/profile/khaledr2346" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/hackerrank.svg" alt="aim97" height="30" width="40" /></a>
<!-- codeforces -->
<a href="https://codeforces.com/profile/Khaled-Ramadan" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/codeforces.svg" alt="aim97" height="30" width="40" /></a>



<h3 align="left">Languages and Tools:</h3>
<p align="left">
<a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/javascript-colored.svg" width="36" height="36" alt="JavaScript" /></a>
        <a href="https://git-scm.com/" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/git-colored.svg" width="36" height="36" alt="Git" /></a>
        <a href="https://docs.microsoft.com/en-us/cpp/?view=msvc-170" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/c-colored.svg" width="36" height="36" alt="C" /></a>
        <a href="https://docs.microsoft.com/en-us/cpp/?view=msvc-170" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/cplusplus-colored.svg" width="36" height="36" alt="C++" /></a>
        <a href="https://www.python.org/" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/python-colored.svg" width="36" height="36" alt="Python" /></a>
        <a href="https://developer.mozilla.org/en-US/docs/Glossary/HTML5" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/html5-colored.svg" width="36" height="36" alt="HTML5" /></a>
        <a href="https://reactjs.org/" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/react-colored.svg" width="36" height="36" alt="React" /></a>
        <a href="https://www.w3.org/TR/CSS/#css" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/css3-colored.svg" width="36" height="36" alt="CSS3" /></a></a>
        <a href="https://chakra-ui.com/" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/chakra-colored.svg" width="36" height="36" alt="Chakra UI" /></a>
        <a href="https://nodejs.org/en/" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/nodejs-colored.svg" width="36" height="36" alt="NodeJS" /></a>
        <a href="https://expressjs.com/" target="_blank" rel="noreferrer"><img src="https://raw.githubusercontent.com/danielcranney/readme-generator/main/public/icons/skills/express-colored.svg" width="36" height="36" alt="Express" /></a>
<a
				href="https://www.mongodb.com/"
				target="_blank"
				rel="noreferrer">
				<img
					src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original-wordmark.svg"
					alt="mongodb"
					width="40"
					height="40" />
			</a>
			<a
				href="https://www.mysql.com/"
				target="_blank"
				rel="noreferrer">
				<img
					src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg"
					alt="mysql"
					width="40"
					height="40" />
			</a>
   			<a
				href="https://nodejs.org"
				target="_blank"
				rel="noreferrer">
				<img
					src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original-wordmark.svg"
					alt="nodejs"
					width="40"
					height="40" />
			</a>
<a
				href="https://pandas.pydata.org/"
				target="_blank"
				rel="noreferrer">
				<img
					src="https://raw.githubusercontent.com/devicons/devicon/2ae2a900d2f041da66e950e4d48052658d850630/icons/pandas/pandas-original.svg"
					alt="pandas"
					width="40"
					height="40" />
			</a>
			<a
				href="https://postman.com"
				target="_blank"
				rel="noreferrer">
				<img
					src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg"
					alt="postman"
					width="40"
					height="40" />
			</a>
</p>



<p><img align = "center" src="https://github-readme-stats.vercel.app/api?username=khaled-Ramdan&show_icons=true&locale=en" alt="khaled-Ramdan" /></p>

<p><img align = "center"  src="https://github-readme-streak-stats.herokuapp.com/?user=khaled-Ramdan&" alt="khaled-Ramdan" /></p>
